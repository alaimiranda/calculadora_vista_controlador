public interface CalculadoraObserver {
    boolean activo = false;
    void updateResultado(double resultado);
}
