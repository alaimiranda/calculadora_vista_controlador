public interface CalculadoraObserver {
    void updateResultado(double resultado);
}
